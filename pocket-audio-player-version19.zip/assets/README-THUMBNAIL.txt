AUDIO POSTER THUMBNAIL
======================

Please add your own "audio-poster.jpg" file to this /assets/ folder.

Requirements:
- Filename: audio-poster.jpg (exactly this name)
- Size: 120x120 pixels 
- Format: JPG/JPEG
- Quality: Recommended 80-90% for best balance of quality/size

This image will be used as the default thumbnail when:
- No M3U thumbnail is specified (#EXTIMG: tag)
- No ID3 embedded artwork is found in the audio file

You can swap out this image anytime to change the default appearance
of your audio player across your entire website.